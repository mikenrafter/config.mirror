#include QMK_KEYBOARD_H
#include "version.h"
#include "keymap_german.h"
#include "keymap_nordic.h"
#include "keymap_french.h"
#include "keymap_spanish.h"
#include "keymap_hungarian.h"
#include "keymap_swedish.h"
#include "keymap_br_abnt2.h"
#include "keymap_canadian_multilingual.h"
#include "keymap_german_ch.h"
#include "keymap_jp.h"
#include "keymap_bepo.h"
#include "keymap_italian.h"
#include "keymap_slovenian.h"
#include "keymap_danish.h"
#include "keymap_norwegian.h"
#include "keymap_portuguese.h"
#include "keymap_contributions.h"
#include "keymap_czech.h"
#include "keymap_romanian.h"
#include "keymap_russian.h"
#include "keymap_uk.h"
#include "keymap_estonian.h"

#define KC_MAC_UNDO LGUI(KC_Z)
#define KC_MAC_CUT LGUI(KC_X)
#define KC_MAC_COPY LGUI(KC_C)
#define KC_MAC_PASTE LGUI(KC_V)
#define KC_PC_UNDO LCTL(KC_Z)
#define KC_PC_CUT LCTL(KC_X)
#define KC_PC_COPY LCTL(KC_C)
#define KC_PC_PASTE LCTL(KC_V)
#define ES_LESS_MAC KC_GRAVE
#define ES_GRTR_MAC LSFT(KC_GRAVE)
#define ES_BSLS_MAC ALGR(KC_6)
#define NO_PIPE_ALT KC_GRAVE
#define NO_BSLS_ALT KC_EQUAL
#define LSA_T(kc) MT(MOD_LSFT | MOD_LALT, kc)
#define BP_NDSH_MAC ALGR(KC_8)
#define MOON_LED_LEVEL LED_LEVEL

enum custom_keycodes {
  RGB_SLD = ML_SAFE_RANGE,
};

const uint16_t PROGMEM keymaps[][MATRIX_ROWS][MATRIX_COLS] = {
  [0] = LAYOUT_moonlander(
    KC_GRAVE,       KC_1,           KC_2,           KC_3,           KC_4,           KC_5,           LGUI(KC_L),                                     KC_BSLASH,      KC_6,           KC_7,           KC_8,           KC_9,           KC_0,           KC_DELETE,      
    MT(MOD_HYPR, KC_TAB),KC_Q,           KC_W,           KC_F,           KC_P,           KC_G,           KC_AUDIO_MUTE,                                  KC_EQUAL,       KC_J,           KC_L,           KC_U,           KC_Y,           KC_SCOLON,      KC_BSPACE,      
    LSFT_T(KC_BSPACE),KC_A,           KC_R,           KC_S,           KC_T,           KC_D,           KC_HOME,                                                                        KC_END,         KC_H,           KC_N,           KC_E,           KC_I,           KC_O,           KC_QUOTE,       
    KC_LCTRL,       KC_Z,           KC_X,           KC_C,           KC_V,           KC_B,                                           KC_K,           KC_M,           KC_COMMA,       KC_DOT,         KC_SLASH,       KC_BSLASH,      
    KC_LALT,        KC_PGUP,        KC_PGDOWN,      KC_LALT,        KC_LGUI,        KC_AUDIO_VOL_DOWN,                                                                                                KC_AUDIO_VOL_UP,LT(1,KC_SPACE), LT(2,KC_MINUS), LCTL(KC_PGUP),  LCTL(KC_PGDOWN),TO(3),          
    KC_SPACE,       KC_ESCAPE,      KC_TAB,                         KC_TAB,         KC_ENTER,       RSFT_T(KC_SPACE)
  ),
  [1] = LAYOUT_moonlander(
    KC_TRANSPARENT, KC_F1,          KC_F2,          KC_F3,          KC_F4,          KC_F5,          KC_NO,                                          KC_TRANSPARENT, KC_F6,          KC_F7,          KC_F8,          KC_F9,          KC_F10,         KC_F11,         
    KC_LALT,        KC_LCTRL,       KC_LSHIFT,      KC_TAB,         KC_PSCREEN,     KC_TRANSPARENT, KC_TRANSPARENT,                                 KC_TRANSPARENT, KC_TRANSPARENT, KC_LSHIFT,      KC_RSHIFT,      KC_LBRACKET,    KC_RBRACKET,    KC_F12,         
    KC_LALT,        KC_LCTRL,       KC_LSHIFT,      KC_TAB,         KC_TRANSPARENT, KC_RALT,        KC_TRANSPARENT,                                                                 KC_TRANSPARENT, KC_LEFT,        KC_DOWN,        KC_UP,          KC_RIGHT,       KC_COLN,        KC_RCTRL,       
    KC_LALT,        KC_LCTRL,       KC_LSHIFT,      KC_TAB,         KC_TRANSPARENT, KC_TRANSPARENT,                                 KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT, 
    MU_TOG,         MU_MOD,         KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT, KC_BRIGHTNESS_DOWN,                                                                                                KC_BRIGHTNESS_UP,KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT, 
    KC_MEDIA_PREV_TRACK,KC_MEDIA_PLAY_PAUSE,KC_MEDIA_NEXT_TRACK,                KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT
  ),
  [2] = LAYOUT_moonlander(
    KC_TRANSPARENT, KC_F1,          KC_F2,          KC_F3,          KC_F4,          KC_F5,          LALT(KC_PSCREEN),                                KC_TRANSPARENT, KC_F6,          KC_F7,          KC_F8,          KC_F9,          KC_F10,         KC_F11,         
    KC_LALT,        KC_LCTRL,       KC_LSHIFT,      KC_TAB,         KC_PSCREEN,     KC_TRANSPARENT, KC_TRANSPARENT,                                 KC_TRANSPARENT, KC_KP_EQUAL,    KC_KP_7,        KC_KP_8,        KC_KP_9,        KC_KP_ASTERISK, KC_F12,         
    KC_LALT,        KC_LCTRL,       KC_LSHIFT,      KC_TAB,         KC_TRANSPARENT, KC_RALT,        KC_TRANSPARENT,                                                                 KC_TRANSPARENT, KC_KP_0,        KC_KP_4,        KC_KP_5,        KC_KP_6,        KC_KP_PLUS,     KC_NUMLOCK,     
    KC_LALT,        KC_LCTRL,       KC_LSHIFT,      KC_TAB,         KC_TRANSPARENT, KC_TRANSPARENT,                                 KC_KP_DOT,      KC_KP_1,        KC_KP_2,        KC_KP_3,        KC_BSLASH,      KC_TRANSPARENT, 
    MU_TOG,         MU_MOD,         KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT, KC_BRIGHTNESS_DOWN,                                                                                                KC_BRIGHTNESS_UP,KC_KP_0,        KC_TRANSPARENT, KC_RCTRL,       KC_LALT,        KC_TRANSPARENT, 
    KC_MEDIA_PREV_TRACK,KC_MEDIA_PLAY_PAUSE,KC_MEDIA_NEXT_TRACK,                KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT
  ),
  [3] = LAYOUT_moonlander(
    KC_ESCAPE,      KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT, KC_NO,                                          KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT, TO(4),          
    KC_TAB,         KC_TRANSPARENT, KC_TRANSPARENT, KC_E,           KC_R,           KC_T,           KC_TRANSPARENT,                                 KC_TRANSPARENT, KC_Y,           KC_U,           KC_I,           KC_O,           KC_P,           TO(4),          
    KC_LSHIFT,      KC_A,           KC_S,           KC_D,           KC_F,           KC_G,           KC_TRANSPARENT,                                                                 KC_TRANSPARENT, KC_TRANSPARENT, KC_J,           KC_K,           KC_L,           KC_SCOLON,      TO(0),          
    KC_LCTRL,       KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT,                                 KC_N,           KC_TRANSPARENT, KC_COMMA,       KC_DOT,         KC_TRANSPARENT, TO(0),          
    KC_LALT,        KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT,                                                                                                 KC_TRANSPARENT, KC_TRANSPARENT, KC_RSHIFT,      KC_LALT,        KC_RCTRL,       TO(0),          
    KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT,                 KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT
  ),
  [4] = LAYOUT_moonlander(
    KC_ESCAPE,      KC_ESCAPE,      KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT, TO(3),                                          TO(0),          KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT, KC_ESCAPE,      KC_ESCAPE,      
    KC_LSHIFT,      KC_LCTRL,       KC_Q,           KC_W,           KC_E,           KC_T,           TO(3),                                          TO(0),          KC_Y,           KC_DOT,         KC_UP,          KC_SLASH,       KC_RCTRL,       KC_LSHIFT,      
    KC_LCTRL,       KC_LSHIFT,      KC_A,           KC_S,           KC_D,           KC_G,           TO(3),                                                                          TO(0),          KC_H,           KC_LEFT,        KC_DOWN,        KC_RIGHT,       KC_RSHIFT,      KC_LCTRL,       
    KC_LSHIFT,      KC_LCTRL,       KC_DOT,         KC_UP,          KC_SLASH,       KC_SPACE,                                       KC_TAB,         KC_Q,           KC_W,           KC_E,           KC_RCTRL,       KC_LSHIFT,      
    KC_LCTRL,       KC_LSHIFT,      KC_LEFT,        KC_DOWN,        KC_RIGHT,       KC_TRANSPARENT,                                                                                                 KC_TRANSPARENT, KC_A,           KC_S,           KC_D,           KC_RSHIFT,      KC_LCTRL,       
    KC_SPACE,       KC_SPACE,       KC_TAB,                         KC_SPACE,       KC_TAB,         KC_TAB
  ),
};

extern bool g_suspend_state;
extern rgb_config_t rgb_matrix_config;

void keyboard_post_init_user(void) {
  rgb_matrix_enable();
}

const uint8_t PROGMEM ledmap[][DRIVER_LED_TOTAL][3] = {
    [0] = { {0,0,255}, {105,255,255}, {105,255,255}, {35,255,255}, {35,255,255}, {14,222,242}, {0,0,0}, {0,0,0}, {0,0,0}, {154,255,255}, {14,222,242}, {0,0,0}, {0,0,0}, {0,0,0}, {154,255,255}, {14,222,242}, {0,0,0}, {0,0,0}, {0,0,0}, {35,255,255}, {14,222,242}, {0,0,0}, {0,0,0}, {0,0,0}, {35,255,255}, {14,222,242}, {0,0,0}, {0,0,0}, {0,0,0}, {202,255,255}, {154,255,255}, {154,255,255}, {0,0,0}, {0,0,0}, {0,0,0}, {134,255,213}, {85,203,158}, {85,203,158}, {0,0,255}, {0,0,255}, {249,228,255}, {14,222,242}, {0,0,255}, {0,0,0}, {0,0,255}, {154,255,255}, {14,222,242}, {0,0,0}, {0,0,0}, {0,0,255}, {154,255,255}, {14,222,242}, {0,0,0}, {0,0,0}, {0,0,255}, {105,255,255}, {14,222,242}, {0,0,0}, {0,0,0}, {0,0,0}, {105,255,255}, {14,222,242}, {0,0,0}, {0,0,0}, {0,0,0}, {0,0,255}, {0,0,255}, {154,255,255}, {105,255,255}, {0,0,0}, {0,0,0}, {134,255,213} },

    [1] = { {0,0,0}, {154,255,255}, {154,255,255}, {154,255,255}, {35,255,255}, {134,255,213}, {105,255,255}, {105,255,255}, {105,255,255}, {35,255,255}, {134,255,213}, {154,255,255}, {154,255,255}, {154,255,255}, {0,0,0}, {134,255,213}, {105,255,255}, {105,255,255}, {105,255,255}, {0,0,0}, {134,255,213}, {249,228,255}, {0,0,0}, {0,0,0}, {0,0,0}, {134,255,213}, {0,0,0}, {249,228,255}, {0,0,0}, {0,0,0}, {0,0,0}, {0,0,0}, {0,0,255}, {0,255,255}, {0,0,255}, {0,0,185}, {134,255,213}, {134,255,213}, {0,0,0}, {0,0,0}, {0,0,0}, {134,255,213}, {0,0,255}, {0,0,255}, {0,0,0}, {0,0,0}, {134,255,213}, {0,0,255}, {154,255,255}, {0,0,0}, {0,0,0}, {134,255,213}, {35,255,255}, {105,255,255}, {0,0,0}, {0,0,0}, {134,255,213}, {35,255,255}, {105,255,255}, {0,0,0}, {10,225,255}, {134,255,213}, {0,0,0}, {154,255,255}, {0,0,0}, {0,0,0}, {0,0,0}, {0,0,0}, {105,255,255}, {0,0,0}, {0,0,0}, {0,0,255} },

    [2] = { {0,0,0}, {154,255,255}, {154,255,255}, {154,255,255}, {35,255,255}, {134,255,213}, {105,255,255}, {105,255,255}, {105,255,255}, {35,255,255}, {134,255,213}, {154,255,255}, {154,255,255}, {154,255,255}, {0,0,0}, {134,255,213}, {105,255,255}, {105,255,255}, {105,255,255}, {0,0,0}, {134,255,213}, {249,228,255}, {0,0,0}, {0,0,0}, {0,0,0}, {134,255,213}, {0,0,0}, {249,228,255}, {0,0,0}, {0,255,255}, {0,0,0}, {0,0,0}, {0,0,255}, {0,255,255}, {0,0,255}, {0,0,185}, {134,255,213}, {134,255,213}, {35,255,255}, {0,0,0}, {0,0,0}, {134,255,213}, {0,0,255}, {0,0,255}, {0,0,255}, {35,255,255}, {134,255,213}, {10,225,255}, {10,225,255}, {10,225,255}, {35,255,255}, {134,255,213}, {10,225,255}, {10,225,255}, {10,225,255}, {35,255,255}, {134,255,213}, {10,225,255}, {10,225,255}, {10,225,255}, {10,225,255}, {134,255,213}, {0,0,255}, {35,255,255}, {0,0,255}, {0,0,0}, {0,0,0}, {0,0,0}, {105,255,255}, {0,0,0}, {0,0,0}, {0,0,255} },

    [3] = { {249,228,255}, {105,255,255}, {35,255,255}, {154,255,255}, {105,255,255}, {0,0,0}, {0,0,0}, {154,255,255}, {0,0,0}, {0,0,0}, {0,0,0}, {105,255,255}, {154,255,255}, {0,0,0}, {0,0,0}, {0,0,0}, {0,0,0}, {154,255,255}, {0,0,0}, {0,0,0}, {0,0,0}, {0,0,0}, {0,0,0}, {0,0,0}, {0,0,0}, {0,0,0}, {0,0,0}, {0,0,0}, {0,0,0}, {0,0,0}, {0,0,0}, {0,0,0}, {105,255,255}, {0,0,0}, {0,0,0}, {134,255,213}, {35,255,255}, {35,255,255}, {10,225,255}, {14,255,255}, {10,225,255}, {0,0,0}, {0,0,0}, {0,0,255}, {0,0,255}, {154,255,255}, {0,0,0}, {0,0,0}, {0,0,0}, {0,0,255}, {105,255,255}, {0,0,0}, {0,0,0}, {0,0,0}, {0,0,255}, {35,255,255}, {0,0,0}, {0,0,0}, {0,0,0}, {0,0,0}, {0,0,0}, {0,0,0}, {0,0,0}, {0,0,0}, {0,0,0}, {0,0,255}, {0,0,255}, {0,0,0}, {105,255,255}, {0,0,0}, {0,0,0}, {134,255,213} },

    [4] = { {249,228,255}, {35,255,255}, {105,255,255}, {35,255,255}, {154,255,255}, {249,228,255}, {105,255,255}, {35,255,255}, {154,255,255}, {35,255,255}, {0,0,0}, {0,0,0}, {0,0,0}, {0,0,0}, {0,0,0}, {0,0,0}, {105,255,255}, {0,0,0}, {154,255,255}, {0,0,0}, {0,0,0}, {0,0,0}, {0,0,0}, {0,0,0}, {0,0,0}, {0,0,0}, {0,0,0}, {0,0,0}, {105,255,255}, {35,255,255}, {35,255,255}, {35,255,255}, {105,255,255}, {105,255,255}, {154,255,255}, {134,255,213}, {249,228,255}, {35,255,255}, {105,255,255}, {35,255,255}, {154,255,255}, {249,228,255}, {105,255,255}, {35,255,255}, {154,255,255}, {35,255,255}, {0,0,0}, {0,0,0}, {0,0,0}, {0,0,0}, {0,0,0}, {0,0,0}, {105,255,255}, {0,0,0}, {154,255,255}, {0,0,0}, {0,0,0}, {0,0,0}, {0,0,0}, {0,0,0}, {0,0,0}, {0,0,0}, {0,0,0}, {0,0,0}, {105,255,255}, {14,255,255}, {14,255,255}, {14,255,255}, {105,255,255}, {105,255,255}, {154,255,255}, {134,255,213} },

};

void set_layer_color(int layer) {
  for (int i = 0; i < DRIVER_LED_TOTAL; i++) {
    HSV hsv = {
      .h = pgm_read_byte(&ledmap[layer][i][0]),
      .s = pgm_read_byte(&ledmap[layer][i][1]),
      .v = pgm_read_byte(&ledmap[layer][i][2]),
    };
    if (!hsv.h && !hsv.s && !hsv.v) {
        rgb_matrix_set_color( i, 0, 0, 0 );
    } else {
        RGB rgb = hsv_to_rgb( hsv );
        float f = (float)rgb_matrix_config.hsv.v / UINT8_MAX;
        rgb_matrix_set_color( i, f * rgb.r, f * rgb.g, f * rgb.b );
    }
  }
}

void rgb_matrix_indicators_user(void) {
  if (g_suspend_state || keyboard_config.disable_layer_led) { return; }
  switch (biton32(layer_state)) {
    case 0:
      set_layer_color(0);
      break;
    case 1:
      set_layer_color(1);
      break;
    case 2:
      set_layer_color(2);
      break;
    case 3:
      set_layer_color(3);
      break;
    case 4:
      set_layer_color(4);
      break;
   default:
    if (rgb_matrix_get_flags() == LED_FLAG_NONE)
      rgb_matrix_set_color_all(0, 0, 0);
    break;
  }
}

bool process_record_user(uint16_t keycode, keyrecord_t *record) {
  switch (keycode) {
    case RGB_SLD:
      if (record->event.pressed) {
        rgblight_mode(1);
      }
      return false;
  }
  return true;
}
